package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}
package com.google.gson;

public enum LongSerializationPolicy
{
  DEFAULT, 

  STRING;
}
package net.minecraft.launcher.hopper;

public class PublishRequest
{
  private Report report;

  public PublishRequest(Report report)
  {
    this.report = report;
  }
}
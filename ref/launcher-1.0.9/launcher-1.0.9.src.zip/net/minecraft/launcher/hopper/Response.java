package net.minecraft.launcher.hopper;

public class Response
{
  private String error;

  public String getError()
  {
    return this.error;
  }
}
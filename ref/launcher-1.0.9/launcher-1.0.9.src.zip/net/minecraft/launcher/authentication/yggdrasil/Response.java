package net.minecraft.launcher.authentication.yggdrasil;

public class Response
{
  private String error;
  private String errorMessage;

  public String getError()
  {
    return this.error;
  }

  public String getErrorMessage() {
    return this.errorMessage;
  }
}